from setuptools import setup
import setuptools

setup(name='sql_panda_test',
      version='6.0.0',
      description='Panda wrapper testtt',

      author='Noah Sragow',
      author_email='nsragow@gmail.com',
      license='MIT',
      packages=setuptools.find_packages(),
      zip_safe=False)
