def print_hi():
    print("hi")
